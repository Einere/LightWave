package com.example.einere.myapplication.history;

class Task {
    String taskName = "";
    String landNo = "";
}
